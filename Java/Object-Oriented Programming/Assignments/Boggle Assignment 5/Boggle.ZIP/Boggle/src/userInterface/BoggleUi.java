/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import core.Board;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Juan
 */
public class BoggleUi {
    /*
    Boggle Assignment 4
    */
    
    //Member variables
    JFrame frame;
    JMenuBar menuBar;
    JMenu Boggle;
    JMenuItem exit;
    JMenuItem newGame;
    JPanel currWord;
    JButton[][] diceButtons;
    JPanel buttonsPanel;
    JScrollPane scrollPane;
    JTextArea textArea;
    JLabel playerScore;
    JButton submitButton;
    JPanel boxPanel;
    JLabel createdWord;
    JButton shakeDiceButton;
    JLabel timeLeft;
    Board boardReceived;
    
    /*
    Boggle Assignment 5
    */

    Timer timer;
    int minutes;
    int seconds;
    exitAction exitEvent;
    resettingBoard resetBoard;
    timerAction timeEvent;
    static final String EMPTY_SPACE = " ";
    
        
    //Methods
    private void initComponents() {
        //Initialize JFrame
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Size configurations    
        Dimension frameSize = new Dimension(900,700);
        frame.setSize(frameSize);
        frame.setMinimumSize(frameSize);
        frame.setPreferredSize(frameSize);
        frame.setResizable(false);
        
        //JMenuBar menuBar
        menuBar = new JMenuBar();
        //JMenu Boggle
        Boggle = new JMenu("Boggle");
        Boggle.setMnemonic('B');  
        //Add newGame and exit to Boggle
        newGame = new JMenuItem("New Game");
        newGame.setMnemonic('N');
        newGame.addActionListener(resetBoard);
        exit = new JMenuItem("Exit");
        exit.setMnemonic('E'); 
        exit.addActionListener(exitEvent);
        Boggle.add(newGame);    
        Boggle.add(exit);
        //Add Boggle to menuBar
        menuBar.add(Boggle);
        //Add menuBar to frame
        frame.add(menuBar,BorderLayout.NORTH);
        
        //JPanel currWord
        currWord = new JPanel();
        currWord.setLayout(new FlowLayout());
        currWord.setPreferredSize(new Dimension(300,75));
        //Components
        playerScore = new JLabel("Score Placeholder",JLabel.CENTER);
        playerScore.setSize(20,20);
        playerScore.setBorder(BorderFactory.createTitledBorder("Player Score"));
        createdWord = new JLabel("Word Placeholder",JLabel.CENTER);
        createdWord.setSize(20,20);
        createdWord.setBorder(BorderFactory.createTitledBorder("Current Word"));
        submitButton = new JButton("Submit Word");
        //Add components
        currWord.add(playerScore,FlowLayout.LEFT);
        currWord.add(submitButton,FlowLayout.CENTER);
        currWord.add(createdWord,FlowLayout.RIGHT);
        
        currWord.setBorder(
                BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(
                    EtchedBorder.RAISED, Color.GRAY,Color.LIGHT_GRAY
                    ),
                "Current Word",
                TitledBorder.DEFAULT_JUSTIFICATION,
                TitledBorder.DEFAULT_POSITION,
                null
                )
        );
        
        //JPanel buttonsPanel
        buttonsPanel = new JPanel();
        Dimension buttonsPanelSize = new Dimension(10,10);
        Dimension buttonSize = new Dimension(1,1);
        GridLayout gridLayout = new GridLayout(4,4,2,2);
        buttonsPanel.setPreferredSize(buttonsPanelSize);
        gridLayout.preferredLayoutSize(buttonsPanel);        
        buttonsPanel.setLayout(gridLayout);
               
        //Components
        diceButtons = new JButton[Board.GRID][Board.GRID];
        //Create buttons and add letters
        int k = 0;
        for (int i = 0; i < Board.GRID; i++) {
            diceButtons[i] = new JButton[Board.GRID];
            for (int j = 0; j < Board.GRID; j++) {
                diceButtons[i][j] = new JButton();
                diceButtons[i][j].setMaximumSize(buttonSize);
                diceButtons[i][j].setPreferredSize(buttonSize);
                diceButtons[i][j].setText(boardReceived.getGameData().get(k));
                diceButtons[i][j].setFont(new Font("Georgia",Font.PLAIN,60));
                buttonsPanel.add(diceButtons[i][j]);
                k++;
            }      
        }
        buttonsPanel.setBorder(
                BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(
                    EtchedBorder.RAISED, Color.GRAY,Color.LIGHT_GRAY
                    ),
                "Boggle Board",
                TitledBorder.DEFAULT_JUSTIFICATION,
                TitledBorder.DEFAULT_POSITION,
                null
                )
        );
        
        //JPanel boxPanel
        boxPanel = new JPanel();
        boxPanel.setLayout(new BoxLayout(boxPanel,BoxLayout.Y_AXIS));
        boxPanel.setOpaque(true);
        boxPanel.setBorder(BorderFactory.createEtchedBorder());
        Dimension boxPanelSize = new Dimension(200,50);
        boxPanel.setPreferredSize(boxPanelSize);
        boxPanel.setSize(boxPanelSize);
        boxPanel.setMinimumSize(boxPanelSize);
        //Components
        textArea = new JTextArea(50,15);
        Dimension textAreaSize = new Dimension(50,15);
        textArea.setPreferredSize(textAreaSize);
        textArea.setToolTipText("Enter a word.");
        textArea.setBorder(
            BorderFactory.createTitledBorder(
            BorderFactory.createEtchedBorder(
                    EtchedBorder.RAISED, Color.GRAY
                    , Color.LIGHT_GRAY), "Enter Words Found"));
        scrollPane = new JScrollPane(textArea);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setPreferredSize(textAreaSize);
        String wordInput = textArea.getText();
        //Timer
        minutes = 3;
        seconds = 0;
        timer = new Timer(1000,timeEvent);
        timer.start();  
        //Time left
        timeLeft = new JLabel();
        Dimension timeLeftSize = new Dimension (100,54);
        timeLeft.setText(EMPTY_SPACE + Integer.toString(minutes) + ":" + Integer.toString(
        seconds) + "0" + EMPTY_SPACE);
        timeLeft.setFont(new Font("",Font.BOLD,30));
        timeLeft.setForeground(Color.RED);              
        timeLeft.setBorder(
                BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(
                    EtchedBorder.RAISED, Color.GRAY,Color.LIGHT_GRAY
                    ),
                "Time Left",
                TitledBorder.DEFAULT_JUSTIFICATION,
                TitledBorder.DEFAULT_POSITION,
                null
                )
        );
        timeLeft.setPreferredSize(timeLeftSize);
        timeLeft.setMinimumSize(timeLeftSize);  
        timeLeft.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        shakeDiceButton = new JButton("Shake Dice");
        shakeDiceButton.setFont(new Font("Georgia",Font.BOLD,25));
        shakeDiceButton.setAlignmentX(JButton.CENTER_ALIGNMENT);
        shakeDiceButton.addActionListener(resetBoard);
        shakeDiceButton.setPreferredSize(new Dimension (30,50));
        textArea.setLineWrap(true);
        boxPanel.add(timeLeft,JPanel.RIGHT_ALIGNMENT);
        boxPanel.add(shakeDiceButton,JPanel.RIGHT_ALIGNMENT);
        boxPanel.add(Box.createRigidArea(new Dimension(0,2)));
        boxPanel.add(scrollPane,JPanel.CENTER_ALIGNMENT);       
        
        //Add components to frame
        frame.add(boxPanel,BorderLayout.EAST);
        frame.add(buttonsPanel,BorderLayout.CENTER);
        frame.add(currWord,BorderLayout.SOUTH);
        
        
        //Set visible
        frame.pack();
        frame.setLocation(250,75);
        frame.setVisible(true);            
    }
    //Custom constructor
    public BoggleUi(Board boardSent){  
        //Get board
        boardReceived = boardSent;
        //Instantiate action listeners
        exitEvent = new exitAction();
        resetBoard = new resettingBoard();
        timeEvent = new timerAction();
        //Initialize components
        initComponents();
    }
    
    //Inner classes
    public class resettingBoard implements ActionListener {   
        //Methods
        @Override
        public void actionPerformed(ActionEvent e) {
            
            boardReceived.shakeDice();
            //Add new letters
            int k = 0;
            for (int i = 0; i < Board.GRID; i++) {
                for (int j = 0; j < Board.GRID; j++) {
                    boardReceived.shakeDice().get(i);
                    diceButtons[i][j].setText(boardReceived.getGameData().get(k));
                    k++;
                }      
            }
            boardReceived.displayGameData();
            
            //Reset text
            textArea.setText("");
            playerScore.setText("0");
            createdWord.setText("");
            
            //Reset frame
            frame.revalidate();
            frame.repaint();
            
            //Reset timer
            timer.stop();
            minutes = 3;
            seconds = 0; 
            timeLeft.setText(EMPTY_SPACE + Integer.toString(minutes) + ":"
            + Integer.toString(seconds) + "0" + EMPTY_SPACE);
            timer.start();
        }
    }
    
    public class exitAction implements ActionListener {
        //Member variables
        JOptionPane messagePane;
        //Methods
        @Override
        public void actionPerformed(ActionEvent e) {
            messagePane = new JOptionPane();
            int userResponse = JOptionPane.showConfirmDialog(messagePane,
            "Would you like to exit Boggle?","Exiting",
            JOptionPane.YES_NO_OPTION);

            //Exit if leaving
            if (userResponse == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        }   
    }

    public class timerAction implements ActionListener {
        //Methods
        @Override
        public void actionPerformed(ActionEvent e) {
            //Time has ended
            if (minutes == 0 && seconds == 0)
                timer.stop();
        
            //A minute has passed
            else if (seconds == 0) {
                seconds = 59;
                minutes--;                
            }
            
            //<10 s. remaining
            String explicitZero = new String();
            if(seconds < 10) {
                explicitZero = "0";
            } 
            else
                explicitZero = "";
            
            timeLeft.setText(EMPTY_SPACE + Integer.toString(minutes) + ":" + explicitZero
            + Integer.toString(seconds) + EMPTY_SPACE);
            
            seconds--;
        }
    }
}