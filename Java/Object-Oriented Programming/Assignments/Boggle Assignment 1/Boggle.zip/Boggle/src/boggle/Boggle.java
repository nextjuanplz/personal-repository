/*Juan Manuel Alzate Vanegas
 * COP 3330
 * Boggle Assignment 1
 * 5/28/2017
 */
package boggle;

import javax.swing.JOptionPane;

/**
 *
 * @author Juan Manuel Alzate Vanegas
 */
public class Boggle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Output to the console
        System.out.println("Welcome to Boggle!");
        
        //Pop-up window
        JOptionPane.showMessageDialog(null, "Let's Play Boggle!");
    }
    
}
