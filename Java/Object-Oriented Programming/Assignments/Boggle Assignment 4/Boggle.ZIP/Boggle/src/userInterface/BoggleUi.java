/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import core.Board;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.border.EtchedBorder;

/**
 *
 * @author Juan
 */
public class BoggleUi {
    /*
    Boggle Assignment 4
    */
    
    //Member variables
    JFrame frame;
    JMenuBar menuBar;
    JMenu Boggle;
    JMenuItem exit;
    JMenuItem newGame;
    JPanel currWord;
    JButton[][] diceButtons;
    JPanel buttonsPanel;
    JScrollPane scrollPane;
    JTextArea textArea;
    JLabel playerScore;
    JButton submitButton;
    JPanel boxPanel;
    JLabel createdWord;
    JButton shakeDiceButton;
    JLabel timeLeft;
        
    //Methods
    private void initComponents() {
        //Initialize JFrame
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Size configurations
        frame.setSize(800,600);
        frame.setResizable(false);
        
        //JMenuBar menuBar
        menuBar = new JMenuBar();
        //JMenu Boggle
        Boggle = new JMenu("Boggle");
        Boggle.setMnemonic('B');  
        //Add newGame and exit to Boggle
        newGame = new JMenuItem("New Game");
        newGame.setMnemonic('N'); 
        exit = new JMenuItem("Exit");
        exit.setMnemonic('E'); 
        Boggle.add(newGame);    
        Boggle.add(exit);
        //Add Boggle to menuBar
        menuBar.add(Boggle);
        //Add menuBar to frame
        frame.add(menuBar,BorderLayout.NORTH);
        
        //JPanel currWord
        currWord = new JPanel();
        currWord.setLayout(new FlowLayout());
        //Components
        playerScore = new JLabel("Score Placeholder",JLabel.CENTER);
        playerScore.setSize(20,20);
        playerScore.setBorder(BorderFactory.createTitledBorder("Player Score"));
        createdWord = new JLabel("Word Placeholder",JLabel.CENTER);
        createdWord.setSize(20,20);
        createdWord.setBorder(BorderFactory.createTitledBorder("Current Word"));
        submitButton = new JButton("Submit Word");    
        currWord.add(playerScore,FlowLayout.LEFT);
        currWord.add(submitButton,FlowLayout.CENTER);
        currWord.add(createdWord,FlowLayout.RIGHT);
        
        //JPanel buttonsPanel
        buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new GridLayout(Board.GRID,Board.GRID));
        //Components
        diceButtons = new JButton[Board.GRID][Board.GRID];
        for (int i = 0; i < Board.GRID; i++) {
            diceButtons[i] = new JButton[Board.GRID];
            for (int j = 0; j < Board.GRID; j++) {
                diceButtons[i][j] = new JButton();
                diceButtons[i][j].setSize(10,10);
                buttonsPanel.add(diceButtons[i][j]);
            }      
        }
        
        //JPanel boxPanel
        boxPanel = new JPanel();
        boxPanel.setLayout(new BoxLayout(boxPanel,BoxLayout.Y_AXIS));
        boxPanel.setOpaque(true);
        boxPanel.setBorder(BorderFactory.createEtchedBorder());
        //Components
        textArea = new JTextArea(50,15);
        textArea.setToolTipText("Enter a word.");
        textArea.setBorder(
            BorderFactory.createTitledBorder(
            BorderFactory.createEtchedBorder(
                    EtchedBorder.RAISED, Color.GRAY
                    , Color.LIGHT_GRAY), "Enter Words Found"));
        scrollPane = new JScrollPane(textArea);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        String wordInput = textArea.getText();
        timeLeft = new JLabel("Time Placeholder");
        timeLeft.setBorder(BorderFactory.createTitledBorder("Time Left"));
        timeLeft.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        shakeDiceButton = new JButton("Shake Dice");
        shakeDiceButton.setAlignmentX(JButton.CENTER_ALIGNMENT);
        textArea.setLineWrap(true);
        boxPanel.add(timeLeft,JPanel.RIGHT_ALIGNMENT);
        boxPanel.add(shakeDiceButton,JPanel.RIGHT_ALIGNMENT);
        boxPanel.add(scrollPane,JPanel.CENTER_ALIGNMENT);
       
        //Add components to frame
        frame.add(boxPanel,BorderLayout.EAST);
        frame.add(buttonsPanel,BorderLayout.CENTER);
        frame.add(currWord,BorderLayout.SOUTH);
        
        //Set visible
        frame.setVisible(true);
    }
    
    //Custom constructor
    public BoggleUi (Board board) {   
        //Initialize components
        initComponents();
        //Add letters to buttons
        int k = 0;
        for (int i = 0; i < Board.GRID; i++) {
            for (int j = 0; j < Board.GRID; j++) {
                this.diceButtons[i][j].setText(board.getGameData().get(k));
                k++;
            }                
        }
    }
}