/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.util.ArrayList;

/**
 *
 * @author Juan
 */
public class Die implements IDie {
    /*
    Boggle Assignment 2
    */
    
    //Methods
    @Override
    public String rollDie() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void addLetter(String str1) {
        sides.add(str1);      
    }
    
    @Override
    public void displayLetters() {
        //Loop through sides ArrayList
        for (String str : sides) {
            //print each letter
            System.out.print(" " + str + " ");
        }
        //Add new line
        System.out.print("\n");        
    }

    //Member variables
    private ArrayList<String> sides = new ArrayList();
}
