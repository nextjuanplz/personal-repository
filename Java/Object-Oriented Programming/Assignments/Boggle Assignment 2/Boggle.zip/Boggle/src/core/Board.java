/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.util.ArrayList;

/**
 *
 * @author Juan
 */
public class Board implements IBoard {
    /*
    Boggle Assignment 2
    */
    
    //Custom constructor
    public Board(ArrayList<String> str1, ArrayList<String> str2) {
        //Initialize strings
        this.diceData = str1;
        this.dictionaryData = str2;
        //Initialize game dice
        this.gameDice = new ArrayList<>();
    }

    //Implement IBoard methods
    @Override
    public void populateDice() {
        //Declare new instance of Die
        Die die;
        //Counters
        int i;      //diceData index
        int j;      //dictionaryData index
        int k = 0;  //Separate index so that letters are not repeated
        //Loop through each die
        for (i = 0; i < NUMBER_OF_DICE; i++) {
            //Instantiate die
            die = new Die();
            //Loop through each side
            for (j = 0; j < Die.NUMBER_OF_SIDES; j++) {
                //Add a letter to the side
                die.addLetter(diceData.get(k));
                //Increment k
                k++;
            }
            
            //Display letters of each die on a separate row
            System.out.print("Dice " + i + ":");
            die.displayLetters();
            
            //Add to ArrayList
            gameDice.add(die);
        }   
    }

    @Override
    public void shakeDice() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    //Member variables
    private ArrayList<String> diceData;
    private ArrayList<String> dictionaryData;
    private ArrayList<Die> gameDice;
}