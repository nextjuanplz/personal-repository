/*
 * Karin Whiting
 * COP 3330 Object Oriented Programming
 * University of Central Florida
 */
package core;

import userInterface.Connect4View;

/**
 *
 * @author kwhiting
 */
public class HumanPlayer extends Player 
{
    /**
    * @author Ryan Maguire
    * @param name name of the human player
    */
    public HumanPlayer (String name) 
    {
        super(name);
    }
    
    public int getMove(Connect4State state, Connect4View view) 
    {
        // Get a move for the user
        return view.getUserMove(state);
    }
}
