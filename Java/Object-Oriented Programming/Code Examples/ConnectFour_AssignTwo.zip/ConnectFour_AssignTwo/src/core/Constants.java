/*
 * Karin Whiting
 * COP 3330 Object Oriented Programming
 * University of Central Florida
 */
package core;

/**
 *
 * @author kwhiting
 */
public class Constants 
{
    public final static int ROW = 6; // Board height
    public final static int COL = 7; // Board width
    public final static char EMPTY = '.'; // Indicate empty place
    public final static char CHECKER0 = 'X'; // Indicate the first player's checker
    public final static char CHECKER1 = 'O'; // Indicate second player's checker
    public final static char [] CHECKERS = {CHECKER0, CHECKER1};
}
