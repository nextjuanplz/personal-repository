/*
 * Karin Whiting
 * COP 3330 Object Oriented Programming
 * University of Central Florida
 */
package connectfour;

import core.AiPlayer;
import core.Connect4Game;
import core.HumanPlayer;
import core.Player;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import userInterface.Connect4Ui;
import userInterface.Connect4View;
import userInterface.Connect4ViewText;

/**
 *
 * @author kwhiting
 */
public class ConnectFour 
{
    private static ArrayList<Player> players; 
    private static Connect4Ui frame;

    public static void main(String[] args) 
    {
//        view = new Connect4ViewText();
        frame = new Connect4Ui();
        
        // create the players
        makePlayers();

        // Hold current game state
//        Connect4Game state = new Connect4Game(0, players);
//        view.display(state);
/*        
        while (!state.gameIsOver())
        {
            int move = state.getPlayerToMove().getMove(state, view);
            state.makeMove(move);
            view.display(state);
        }

        if (state.isFull())
            view.reportToUser("It is a draw");
        else
            view.reportToUser(players.get(1 - state.getPlayerNum()).getName() + " wins!");
*/
        }
    /**
    * Constructs a Connect 4 player. If the name contains "Computer" it
    * constructs a computer player; else a human player
    * @param view the view to use to communicate to the world
    * @param playerMsg the player to ask for
    * @return
    */
    public static void makePlayers() 
    {
        // instantiate the players object
        players = new ArrayList<Player>();
        
        // get human player name
        String name = JOptionPane.showInputDialog("Enter your name");
        // instantiate the human player
        Player humanPlayer = new HumanPlayer(name);
        
        // instantiate the computer player
        // default value for now
        int depth = 0;

        Player aiPlayer = new AiPlayer("Computer", depth);
        
        // add players to ArrayList
        players.add(humanPlayer);
        players.add(aiPlayer);
    }        
}