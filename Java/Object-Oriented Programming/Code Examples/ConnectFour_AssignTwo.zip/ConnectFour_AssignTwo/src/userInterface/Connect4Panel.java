/*
 * Karin Whiting
 * COP 3330 Object Oriented Programming
 * University of Central Florida
 */
package userInterface;

import core.Constants;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author kwhiting
 */
public class Connect4Panel extends JPanel
{
    private BoardListener boardListener;
    private RoundButton[][] buttonBoard;

    public Connect4Panel()
    {
        super();
        initComponents();
    }

    private void initComponents()
    {
        this.setLayout(new GridLayout(Constants.ROW, Constants.COL));
        this.setMinimumSize(new Dimension(500, 500));
        this.setPreferredSize(new Dimension(500, 500));
        this.setBackground(Color.BLUE);
        
        // create the board 6 rows x 7 columns
        buttonBoard = new RoundButton [Constants.ROW][Constants.COL];        
        
        // put client properties on the buttons so we
        // know which one it is
        for (int row = 0; row < Constants.ROW; row++)
        {			
            for (int col = 0; col < Constants.COL; col++)
            {
                // create the buttons
                buttonBoard[row][col] = new RoundButton();
                buttonBoard[row][col].putClientProperty("row", row);
                buttonBoard[row][col].putClientProperty("col", col);
                
                // add and action listener
                if(row == 0)
                {
                    setListener(buttonBoard[row][col], boardListener);
                }
                
                // add button to JPanel
                this.add(buttonBoard[row][col]);
                
            }
        }	
        
    }
    
    private BoardListener getBoardListener()
    {
        return boardListener;
    }
    
    private void setListener(JButton inButton, ActionListener inListener)
    {
        inButton.addActionListener(inListener);
    }

    private void removeListener(JButton inButton, ActionListener inListnener)
    {
        inButton.removeActionListener(inListnener);
    }

    private class BoardListener implements ActionListener
    {	
        public void actionPerformed(ActionEvent e) 
        {
            if( e.getSource() instanceof JButton) 
            {               
                // this is an explicit type cast
                JButton button = (JButton)e.getSource();
                int rowClick = (int)button.getClientProperty("row");
                int colClick = (int)button.getClientProperty("col");
            }
        }
    }    
}