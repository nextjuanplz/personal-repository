/*
 * Karin Whiting
 * COP 3330 Object Oriented Programming
 * University of Central Florida
 */
package xmlparsing;

import inputOutput.XmlParser;

/**
 *
 * @author kwhiting
 */
public class XmlParsing 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        XmlParser parser = new XmlParser();
    }
}
