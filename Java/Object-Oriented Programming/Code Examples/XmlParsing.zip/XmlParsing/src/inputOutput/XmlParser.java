/*
 * Karin Whiting
 * COP 3330 Object Oriented Programming
 * University of Central Florida
 */
package inputOutput;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author kwhiting
 */
public class XmlParser 
{
    private ArrayList<Employee> myEmpls = new ArrayList<>();
    private Document document;
    
    public XmlParser()
    {
        System.out.println("----------------------------");
        System.out.println("PARSING XML FILE");
        System.out.println("----------------------------");
        
        parseXmlFile();
        printData();
        
        System.out.println("----------------------------");
        System.out.println("QUERYING XML FILE");
        System.out.println("----------------------------");
        queryXmlFile();
        
        System.out.println("----------------------------");
        System.out.println("WRITING XML FILE");
        System.out.println("----------------------------");
        writeXmlFile();
        
        System.out.println("----------------------------");
        System.out.println("MODIFYING XML FILE");
        System.out.println("----------------------------");
        modifyXmlFile();
    }
    
    private void parseXmlFile()
    {        
        //Get the DOM Builder Factory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try 
        {
            //Using factory get an instance of document builder
            DocumentBuilder db = dbf.newDocumentBuilder();

            //Load and Parse the XML document
            //document contains the complete XML as a Tree.
            document = db.parse(ClassLoader.getSystemResourceAsStream("inputOutput/employees.xml"));
            
            //Iterating through the nodes and extracting the data.
            NodeList nodeList = document.getDocumentElement().getChildNodes();

            for(int i = 0; i < nodeList.getLength(); i++) 
            {
                //get the <Employee> element
                Node node = nodeList.item(i);

                if(node instanceof Element)
                {
                    //for each <employee> element get text or int values of
                    //name ,id, age and name
                    String type = node.getAttributes().getNamedItem("type").getNodeValue();
                    String name = "";
                    int age = 0;
                    int id = 0;
                    
                    NodeList childNodes = node.getChildNodes();

                    for (int j = 0; j < childNodes.getLength(); j++) 
                    {
                        Node cNode = childNodes.item(j);  
 
                        //Identifying the child tag of employee encountered.
                        if (cNode instanceof Element) 
                        {
                            String content = cNode.getLastChild().getTextContent().trim();
                            switch (cNode.getNodeName()) 
                            {
                                case "Name":
                                  name = content;
                                  break;
                                case "Id":
                                  id = Integer.parseInt(content);
                                  break;
                                case "Age":
                                  age = Integer.parseInt(content);
                                  break;
                            }
                        }
                    }
                    //Create a new Employee with the value read from the xml nodes
                    Employee e = new Employee(name, id, age, type);

                    //add it to list
                    myEmpls.add(e);                }
            }
        }
        catch(ParserConfigurationException pce) 
        {
            pce.printStackTrace();
        }
        catch(SAXException se) 
        {
            se.printStackTrace();
        }
        catch(IOException ioe) 
        {
            ioe.printStackTrace();
        }
    }

    private void queryXmlFile()
    {        
        //Get the DOM Builder Factory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try 
        {
            //Using factory get an instance of document builder
            DocumentBuilder db = dbf.newDocumentBuilder();

            //Load and Parse the XML document
            //document contains the complete XML as a Tree.
            document = db.parse(ClassLoader.getSystemResourceAsStream("inputOutput/cars.xml"));
            
            //Iterating through the nodes and extracting the data.
            NodeList nodeList = document.getElementsByTagName("supercars");
            
            for (int temp = 0; temp < nodeList.getLength(); temp++) 
            {
                Node nNode = nodeList.item(temp);
                
                System.out.println("\nCurrent Element :");
                System.out.print(nNode.getNodeName());
                
                if (nNode.getNodeType() == Node.ELEMENT_NODE) 
                {
                    Element eElement = (Element) nNode;

                    System.out.print("company : ");
                    System.out.println(eElement.getAttribute("company"));
                    
                    NodeList carNameList =  eElement.getElementsByTagName("carname");
                    
                    for (int count = 0; count < carNameList.getLength(); count++) 
                    {	 
                        Node node1 = carNameList.item(count);
                        
                        if (node1.getNodeType() == node1.ELEMENT_NODE) 
                        {
                           Element car = (Element) node1;
                           
                           System.out.print("car name : ");
                           System.out.println(car.getTextContent());
                           System.out.print("car type : ");
                           System.out.println(car.getAttribute("type"));
                        }
                    }
                }
            }
        }
        catch(ParserConfigurationException pce) 
        {
            pce.printStackTrace();
        }
        catch(SAXException se) 
        {
            se.printStackTrace();
        }
        catch(IOException ioe) 
        {
            ioe.printStackTrace();
        }
    }

    private void writeXmlFile()
    {
        try 
        {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();
            
            // root element
            Element rootElement = doc.createElement("cars");
            doc.appendChild(rootElement);

            //  supercars element
            Element supercar = doc.createElement("supercars");
            rootElement.appendChild(supercar);

            // setting attribute to element
            Attr attr = doc.createAttribute("company");
            attr.setValue("Ferrari");
            supercar.setAttributeNode(attr);

            // carname element
            Element carname = doc.createElement("carname");
            Attr attrType = doc.createAttribute("type");
            attrType.setValue("formula one");
            carname.setAttributeNode(attrType);
            carname.appendChild(doc.createTextNode("Ferrari 101"));
            supercar.appendChild(carname);

            Element carname1 = doc.createElement("carname");
            Attr attrType1 = doc.createAttribute("type");
            attrType1.setValue("sports");
            carname1.setAttributeNode(attrType1);
            carname1.appendChild(doc.createTextNode("Ferrari 202"));
            supercar.appendChild(carname1);

            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            
            URL url = getClass().getResource("carsOut.xml");
            File outputFile = new File(url.getPath());
            StreamResult result = new StreamResult(outputFile);
            transformer.transform(source, result);
            
            // Output to console for testing
            StreamResult consoleResult = new StreamResult(System.out);
            transformer.transform(source, consoleResult);
            System.out.println("");
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }        

    private void printData()
    {
        System.out.println("No of Employees '" + myEmpls.size() + "'.");

        Iterator it = myEmpls.iterator();

        while(it.hasNext()) 
        {
            System.out.println(it.next().toString());
        }
    }
    
    private class Employee
    {
        private String name;
        private int id;
        private int age;
        private String type;

        //Create a new Employee with the value read from the xml nodes
        public Employee(String inName, int inId, int inAge, String inType)
        {
            name = inName;
            id = inId;
            age = inAge;
            type = inType;
        }
    }
    
    private void modifyXmlFile()
    {
        try 
        {
            URL url = getClass().getResource("carsModify.xml");
            File inputFile = new File(url.getPath());
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(inputFile);
            Node cars = doc.getFirstChild();
            Node supercar = doc.getElementsByTagName("supercars").item(0);

            // update supercar attribute
            NamedNodeMap attr = supercar.getAttributes();
            Node nodeAttr = attr.getNamedItem("company");
            nodeAttr.setTextContent("Lamborigini");

            // loop the supercar child node
            NodeList list = supercar.getChildNodes();

            for (int temp = 0; temp < list.getLength(); temp++) 
            {
                Node node = list.item(temp);
                
                if (node.getNodeType() == Node.ELEMENT_NODE) 
                {
                    Element eElement = (Element) node;
                
                    if ("carname".equals(eElement.getNodeName()))
                    {
                        if("Ferrari 101".equals(eElement.getTextContent()))
                        {
                            eElement.setTextContent("Lamborigini 001");
                        }
                   
                        if("Ferrari 202".equals(eElement.getTextContent()))
                            eElement.setTextContent("Lamborigini 002");
                   }
                }
            }
            
            NodeList childNodes = cars.getChildNodes();
            
            for(int count = 0; count < childNodes.getLength(); count++)
            {
                Node node = childNodes.item(count);
                if("luxurycars".equals(node.getNodeName()))
                    cars.removeChild(node);
           }
            
           // write the content on console
           TransformerFactory transformerFactory = TransformerFactory.newInstance();
           Transformer transformer = transformerFactory.newTransformer();
           DOMSource source = new DOMSource(doc);
           
           System.out.println("-----------Modified File-----------");
           
           StreamResult consoleResult = new StreamResult(System.out);
           transformer.transform(source, consoleResult);
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
}
