package keyterminology;

public class Dog 
{
    private int age;
    private String breed;
    private String name;
    private String activity;
    private boolean hungry;
    
   public Dog()
   {
       
   }
   
    public boolean isHungry()
    {
        return hungry;
    }
    
    public void setName(String name)
    {
        name = name;
    }
}
