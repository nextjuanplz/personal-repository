/*
 * Karin Whiting
 * COP 3330 Object Oriented Programming
 * University of Central Florida
 */
package keyterminology;

public class DogTwo implements IDog
{
    @Override
    public void run() {
    }

    @Override
    public void fetch() {
    }

    @Override
    public void sleep() {
    }

    @Override
    public void eat() {
    }    
}
