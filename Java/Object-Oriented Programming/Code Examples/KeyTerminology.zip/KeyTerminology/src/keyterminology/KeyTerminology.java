/*
 * Karin Whiting
 * COP 3330 Object Oriented Programming
 * University of Central Florida
 */
package keyterminology;

/**
 *
 * @author kwhiting
 */
public class KeyTerminology {

    public static void main(String[] args) {
        // this is a declaration
        Dog dog;
        // this is instantiation
        // it calls the constructor and allocates memory
        Dog puppy = new Dog();
    }
    
}
