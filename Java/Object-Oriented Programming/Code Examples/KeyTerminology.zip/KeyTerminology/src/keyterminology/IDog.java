package keyterminology;

import javax.swing.*;

public interface IDog 
{
    public void run();
    public void fetch();
    public void sleep();
    public void eat();
}
