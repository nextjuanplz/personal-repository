/*
 * Karin Whiting
 * COP 3330 Object Oriented Programming
 * University of Central Florida
 */
package expressionsstatementsblock;

/**
 *
 * @author kwhiting
 */
public class TestClass 
{
    int variableOne = 0;
    int varibleTwo = 1;
    
    public void compare()
    {
        if (variableOne > varibleTwo)
            System.out.println("variableOne is larger");
        else
            System.out.println("variableTwo is larger");
    }
}
