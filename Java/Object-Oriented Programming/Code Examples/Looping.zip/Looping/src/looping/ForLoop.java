/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package looping;

/**
 *
 * @author kwhiting
 */
public class ForLoop 
{
    public void example()
    {
         for(int i=1; i<11; i++)
         {
              System.out.println("Count is: " + i);
         }
    }

    public void infinite()
    {
        for ( ; ; ) 
        {
    
            // your code goes here
        }
    }
}
